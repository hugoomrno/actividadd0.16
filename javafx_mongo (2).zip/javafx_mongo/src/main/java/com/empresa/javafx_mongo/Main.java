import com.mongodb.MongoClientSettings;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;

public class Main extends Application {

    private static final String CONNECTION_STRING = "mongodb+srv://lector:lector@cluster0.lxijdu9.mongodb.net/";
    private static final String DATABASE_NAME = "ejemplo";
    private static final String COLLECTION_NAME = "productos";

    private TableView<Product> tableView;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("MongoDB JavaFX Example");

        // Create the TableView and columns
        tableView = new TableView<>();
        TableColumn<Product, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Product, Double> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        tableView.getColumns().addAll(nameColumn, priceColumn);

        // Create the button and set the action
        Button loadButton = new Button("Load Data");
        loadButton.setOnAction(event -> loadDataFromMongoDB());

        // Layout
        VBox vbox = new VBox(loadButton, tableView);
        Scene scene = new Scene(vbox, 800, 600);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void loadDataFromMongoDB() {
        ObservableList<Product> products = FXCollections.observableArrayList();

        try (var mongoClient = MongoClients.create(CONNECTION_STRING)) {
            MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
            MongoCollection<Document> collection = database.getCollection(COLLECTION_NAME);

            FindIterable<Document> documents = collection.find();
            for (Document doc : documents) {
                String name = doc.getString("name");
                Double price = doc.getDouble("price");
                products.add(new Product(name, price));
            }
        }

        tableView.setItems(products);
    }

    public static class Product {
        private String name;
        private Double price;

        public Product(String name, Double price) {
            this.name
        };
