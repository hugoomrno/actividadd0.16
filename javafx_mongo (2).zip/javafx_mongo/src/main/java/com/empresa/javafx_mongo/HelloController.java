package com.empresa.javafx_mongo;

import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import org.bson.Document;

public class HelloController {
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {

        //welcomeText.setText("Welcome to JavaFX Application!");
        String url="mongodb+srv://lector:lector@cluster0.hbso5zx.mongodb.net/";
        MongoClient conexion=MongoClients.create(url);
        //System.out.println(conexion);
        MongoDatabase database=conexion.getDatabase("practica1");
        MongoCollection<Document> collection=database.getCollection("clientes");
        //System.out.println(collection);

        ObservableList<String> resultados= FXCollections.observableArrayList();
    }
}